package part;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Login {

    private String username;
    private String password;
    private String firstName;
    private String lastName;

//Matcher and pattern was coded with the help of a webiste, however no code was copied from said website.
//https://jenkov.com/tutorials/java-regex/matcher.html#:~:text=Java%20Matcher%20Example,-Here%20is%20a&text=First%20a%20Pattern%20instance%20is,text%2C%20and%20false%20if%20not.
//Jakob Jenkov

    public boolean checkUserName() {
        Pattern pattern = Pattern.compile("^[a-zA-Z0-9_]{1,5}$");
        Matcher matcher = pattern.matcher(username);
        return matcher.matches();
    }

    public boolean checkPasswordComplexity() {
        Pattern pattern = Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$");
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

    public String registerUser(String username, String password, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;

        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }

        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        }

        // Save user to database.

        return "Welcome " + firstName + " " + lastName + ", it is great to see you.";
    }

    public boolean loginUser(String username, String password) {
        this.username = username;
        this.password = password;

        if (!checkUserName() ||!checkPasswordComplexity()) {
            return false;
        }

        // Check if user exists in database.

        return true;
    }

    public String returnLoginStatus() {
        if (checkUserName() && checkPasswordComplexity()) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
