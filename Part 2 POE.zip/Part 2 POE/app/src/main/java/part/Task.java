package part;

import java.util.Random;

public class Task {
    private String taskDescription;
    private int taskDuration;
    private String taskID;

    public Task(String taskName, String taskDescription, String developerDetails, int taskDuration) {
        this.taskDescription = taskDescription;
        this.taskDuration = taskDuration;
        this.taskID = createTaskID();
    }

    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }

    public String createTaskID() {
        String randomString = generateRandomString(2) + ":" + generateRandomString(1) + ":" + generateRandomString(2);
        return randomString;
    }

    private String generateRandomString(int length) {
        int leftLimit = 48; // ASCII for '0'
        int rightLimit = 122; // ASCII for 'z'
        Random random = new Random();
        String generatedString = random.ints(leftLimit, rightLimit + 1)
             .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
             .limit(length)
             .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
             .toString();
        return generatedString;
    }

    public String getTaskID() {
        return taskID;
    }

    public int getTaskDuration() {
        return taskDuration;
    }
}