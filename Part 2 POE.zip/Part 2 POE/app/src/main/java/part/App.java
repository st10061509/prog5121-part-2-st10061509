package part;

import javax.swing.JOptionPane;

import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;

public class App {

    private static List<User> users = new ArrayList<>();
    private static String username = "";
    private static String password = "";
    private static String firstName = "";
    private static String lastName = "";

    public static void main(String[] args) {
        int choice = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Create Account or Log In:\n1. Create Account\n2. Log In",
                "Login",
                JOptionPane.QUESTION_MESSAGE));

        if (choice == 1) {
            registerUser();
            main(null); // call main method again to show login page
        } else if (choice == 2) {
            loginUser();
        }
    }

    public static void registerUser() {
        // Prompt user to enter username
        while (true) {
            String username = JOptionPane.showInputDialog(null,
                    "Enter username:",
                    "Registration",
                    JOptionPane.PLAIN_MESSAGE);

            if (isValidUsernames(username)) {
                if (!checkUserName(username)) {
                    JOptionPane.showMessageDialog(null,
                            "Username already exists. Please choose another username.",
                            "Registration",
                            JOptionPane.ERROR_MESSAGE);
                    continue;
                }
                JOptionPane.showMessageDialog(null,
                        "Username successfully captured",
                        "Registration",
                        JOptionPane.INFORMATION_MESSAGE);
                App.username = username;
                break;
            }
            JOptionPane.showMessageDialog(null,
                    "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.",
                    "Registration",
                    JOptionPane.ERROR_MESSAGE);
        }

        // Prompt user to enter password
        while (true) {
            String password = JOptionPane.showInputDialog(null,
                    "Enter password:",
                    "Registration",
                    JOptionPane.PLAIN_MESSAGE);

            if (isValidPasswords(password)) {
                JOptionPane.showMessageDialog(null,
                        "Password successfully captured",
                        "Registration",
                        JOptionPane.INFORMATION_MESSAGE);
                App.password = password;
                break;
            }
            JOptionPane.showMessageDialog(null,
                    "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.",
                    "Registration",
                    JOptionPane.ERROR_MESSAGE);
        }

        // Prompt user to enter first name
        while (true) {
            String firstName = JOptionPane.showInputDialog(null,
                    "Enter first name:",
                    "Registration",
                    JOptionPane.PLAIN_MESSAGE);

            if (isValidFirstName(firstName)) {
                JOptionPane.showMessageDialog(null,
                        "First name successfully captured",
                        "Registration",
                        JOptionPane.INFORMATION_MESSAGE);
                App.firstName = firstName;
                break;
            }
            JOptionPane.showMessageDialog(null,
                    "First name is required.",
                    "Registration",
                    JOptionPane.ERROR_MESSAGE);
        }

        // Prompt user to enter last name
        while (true) {
            String lastName = JOptionPane.showInputDialog(null,
                    "Enter last name:",
                    "Registration",
                    JOptionPane.PLAIN_MESSAGE);

            if (isValidFirstName(lastName)) {
                JOptionPane.showMessageDialog(null,
                        "Last name successfully captured",
                        "Registration",
                        JOptionPane.INFORMATION_MESSAGE);
                App.lastName = lastName;
                break;
            }
            JOptionPane.showMessageDialog(null,
                    "Last name is required.",
                    "Registration",
                    JOptionPane.ERROR_MESSAGE);
        }

        // Create a new User object with the entered username, password, first name, and
        // last name
        User newUser = new User(username, password, firstName, lastName);

        // Save user data to a file using the FileHandler class
        FileHandler.saveUserData(username, password, firstName, lastName);

        users.add(newUser);

        JOptionPane.showMessageDialog(null,
                "Account successfully created with username " + username,
                "Registration",
                JOptionPane.INFORMATION_MESSAGE);

        // Wait for the user to close the JOptionPane
        int input = JOptionPane.showOptionDialog(null, null, "Login", JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE, null, new Object[] { "Login Page", "Cancel" }, null);

        if (input == JOptionPane.YES_OPTION) {
            main(null);
        }
    }

    public static class FileHandler {

        public static void saveUserData(String username, String password, String firstName, String lastName) {
            try {
                FileWriter myWriter = new FileWriter("users.txt", true);
                myWriter.write(username + "," + password + "," + firstName + "," + lastName + "\n");
                myWriter.close();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null,
                        "An error occurred while saving the user data.",
                        "Registration",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static boolean checkUserName(String userName) {
        for (User user : users) {
            if (user.getUser().equals(userName)) {
                return false;
            }
        }
        return true;
    }

    public static boolean checkPasswordComplexity(String password) {
        return password.matches("(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}");
    }

    public static void loginUser() {
        String username = JOptionPane.showInputDialog(null, "Enter your username:", "Login", JOptionPane.PLAIN_MESSAGE);
        String password = JOptionPane.showInputDialog(null, "Enter your password:", "Login", JOptionPane.PLAIN_MESSAGE);

        // Check if the username and password match a user in the system
        boolean userFound = false;
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                JOptionPane.showMessageDialog(null, "Welcome to EasyKanban", "Welcome",
                        JOptionPane.INFORMATION_MESSAGE);

                // Display options for the user to choose
                while (true) {
                    int choice = Integer.parseInt(JOptionPane.showInputDialog(null,
                            "Choose an option:\n1. Add tasks\n2. Show report\n3. Quit",
                            "Options",
                            JOptionPane.QUESTION_MESSAGE));

                    if (choice == 1) {
                        // Add tasks functionality here
                        addTasks();
                    } else if (choice == 2) {
                        JOptionPane.showMessageDialog(null, "Coming soon!", "Report", JOptionPane.INFORMATION_MESSAGE);
                    } else if (choice == 3) {
                        System.exit(0);
                    }
                }
            }
        }
        if (!userFound) {
            JOptionPane.showMessageDialog(null, "Invalid username or password. Please try again.", "Login",
                    JOptionPane.ERROR_MESSAGE);
            loginUser();
        }
    }

    public static void addTasks() {
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the number of tasks you wish to add:",
                "Add Tasks", JOptionPane.PLAIN_MESSAGE));
        int taskNumber = 0;
        int totalHours = 0;

        // User enters tasks details
        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog(null, "Enter task " + (i + 1) + " name:", "Add Tasks",
                    JOptionPane.PLAIN_MESSAGE);
            String developerFirstName = JOptionPane.showInputDialog(null,
                    "Enter the first name of the developer assigned to the task:", "Add Tasks",
                    JOptionPane.PLAIN_MESSAGE);
            String developerLastName = JOptionPane.showInputDialog(null,
                    "Enter the last name of the developer assigned to the task:", "Add Tasks",
                    JOptionPane.PLAIN_MESSAGE);
            String taskDuration = JOptionPane.showInputDialog(null,
                    "Enter the estimated duration of the task in hours:", "Add Tasks", JOptionPane.PLAIN_MESSAGE);

            int taskDurationHours = Integer.parseInt(taskDuration); // convert the task duration to an integer
            totalHours += taskDurationHours;

            String taskDescription;
            while (true) {
                taskDescription = JOptionPane.showInputDialog(null, "Enter task " + (i + 1) + " description:",
                        "Add Tasks", JOptionPane.PLAIN_MESSAGE);
                if (taskDescription.length() < 50) {
                    JOptionPane.showMessageDialog(null, "Task successfully captured", "Add Tasks",
                            JOptionPane.INFORMATION_MESSAGE);
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters",
                            "Add Tasks", JOptionPane.ERROR_MESSAGE);
                }
            }

            // Generate task ID
            String taskID = taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":"
                    + developerLastName.substring(developerLastName.length() - 3).toUpperCase();

            // Display tasks with JOptionPane.
            int taskStatus = JOptionPane.showOptionDialog(null, "Choose a task status:", "Task Status",
                    JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,
                    new Object[] { "To do", "Doing", "Done" }, null);
            JOptionPane.showMessageDialog(null,
                    "Task Status: " + (taskStatus == 0 ? "To do" : taskStatus == 1 ? "Doing" : "Done")
                            + "\nDeveloper Details: " + developerFirstName + " " + developerLastName + "\nTask Number: "
                            + taskNumber + "\nTask Name: " + taskName + "\nTask Description: " + taskDescription
                            + "\nTask ID: " + taskID + "\nDuration: " + taskDuration + " hours",
                    "Task Details", JOptionPane.INFORMATION_MESSAGE);
            taskNumber++;

            JOptionPane.showMessageDialog(null, "Total hours across all tasks: " + totalHours + " hours",
                    "Task Details", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public static class User {
        private String username;
        private String password;
        private String firstName;
        private String lastName;

        public User(String username, String password, String firstName, String lastName) {
            this.username = username;
            this.password = password;
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public String getUsername() {
            return username;
        }

        public String getPassword() {
            return password;
        }

        public String getFirstName() {
            return firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public String getUser() {
            return username;
        }
    }

    public static boolean isValidUsernames(String username) {
        return username.matches("[a-zA-Z_]{1,5}");
    }

    public static boolean isValidPasswords(String password) {
        return password.matches("(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}");
    }

    public static boolean isValidFirstName(String firstName) {
        return firstName.length() > 0;
    }
}
