package part;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testTaskDescriptionLengthSuccess() {
        Task task = new Task("Create Login to authenticate users", "", "", 8);
        Assertions.assertTrue(task.checkTaskDescription());
    }

    @Test
    public void testDescriptionFailure() {
        Task task = new Task("Create Login to authenticate users and also do something else and more and more", "", "",
                8);
        Assertions.assertTrue(task.checkTaskDescription());
    }

    @Test
    public void testTaskIDGeneration() {
        Task task = new Task("Create Login to authenticate users", "", "", 8);
        String taskID = task.getTaskID();
        Assertions.assertNotNull(taskID);
        String[] parts = taskID.split(":");
        Assertions.assertEquals(3, parts.length);
        Assertions.assertTrue(parts[0].length() > 0);
        Assertions.assertTrue(parts[1].length() > 0);
        Assertions.assertTrue(parts[2].length() > 0);
    }

    @Test
    public void testTotalHoursAccumulation() {
        Task task1 = new Task("Create Login to authenticate users", "", "", 8);
        Task task2 = new Task("Create Add Task feature to add task users", "", "", 10);
        int totalHours = task1.getTaskDuration() + task2.getTaskDuration();
        Assertions.assertEquals(18, totalHours);
    }
}

// Unit testing was coded with the help of Stack overflow, however no code has
// been taken.
// https://stackoverflow.com/questions/57999049/unit-testing-principles?noredirect=1&lq=1
// Marquee
// https://stackoverflow.com/users/631272/marquee