package part;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class LoginTest {

    @Test
    public void testRegisterUser() {
        Login login = new Login();
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!";
        String firstName = "Kyle";
        String lastName = "Reese";

        String result = login.registerUser(username, password, firstName, lastName);

        Assertions.assertEquals("Welcome " + firstName + " " + lastName + ", it is great to see you.", result);
    }

    @Test
    public void testRegisterUserIncorrectUsername() {
        Login login = new Login();
        String username = "kyle!!!!!!!";
        String password = "Ch&&sec@ke99!";
        String firstName = "Kyle";
        String lastName = "Reese";

        String result = login.registerUser(username, password, firstName, lastName);

        Assertions.assertEquals(
                "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.",
                result);
    }

    @Test
    public void testRegisterUserIncorrectPassword() {
        Login login = new Login();
        String username = "kyl_1";
        String password = "password";
        String firstName = "Kyle";
        String lastName = "Reese";

        String result = login.registerUser(username, password, firstName, lastName);

        Assertions.assertEquals(
                "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.",
                result);
    }

    @Test
    public void testLoginUser() {
        Login login = new Login();
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!";

        boolean result = login.loginUser(username, password);

        Assertions.assertTrue(result);
    }

    @Test
    public void testLoginUserIncorrectCredentials() {
        Login login = new Login();
        String username = "kyl_1";
        String password = "ch&&sec@ke99!";

        boolean result = login.loginUser(username, password);

        Assertions.assertFalse(result);
    }
}

// Unit testing was coded with the help of Stack overflow, however no code has
// been taken.
// https://stackoverflow.com/questions/57999049/unit-testing-principles?noredirect=1&lq=1
// Marquee
// https://stackoverflow.com/users/631272/marquee
